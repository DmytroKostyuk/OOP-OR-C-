﻿namespace _05_MordorsCruelPlan.FoodModels
{
    class OtherFood : Food
    {
        public OtherFood() : base(-1) { }
    }
}
