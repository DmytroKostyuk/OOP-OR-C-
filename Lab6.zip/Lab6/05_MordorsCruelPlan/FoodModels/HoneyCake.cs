﻿namespace _05_MordorsCruelPlan.FoodModels
{
    class HoneyCake : Food
    {
        public HoneyCake() : base(5) { }
    }
}
