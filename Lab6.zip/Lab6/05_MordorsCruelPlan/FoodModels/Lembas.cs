﻿namespace _05_MordorsCruelPlan.FoodModels
{
    class Lembas : Food
    {
        public Lembas() : base(3) { }
    }
}
