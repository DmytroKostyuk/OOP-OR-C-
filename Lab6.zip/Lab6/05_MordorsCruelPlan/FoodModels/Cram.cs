﻿namespace _05_MordorsCruelPlan.FoodModels
{
    class Cram : Food
    {
        public Cram() : base(2) { }
    }
}
