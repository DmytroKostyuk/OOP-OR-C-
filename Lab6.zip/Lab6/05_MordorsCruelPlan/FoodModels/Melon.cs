﻿namespace _05_MordorsCruelPlan.FoodModels
{
    class Melon : Food
    {
        public Melon() : base(1) { }
    }
}
