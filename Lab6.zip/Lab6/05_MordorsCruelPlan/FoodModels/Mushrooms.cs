﻿namespace _05_MordorsCruelPlan.FoodModels
{
    class Mushrooms : Food
    {
        public Mushrooms() : base(-10) { }
    }
}
