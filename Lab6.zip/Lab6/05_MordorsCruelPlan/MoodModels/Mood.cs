﻿namespace _05_MordorsCruelPlan.MoodModels
{
    class Mood
    {
        public string Name { get; }

        public Mood(string name)
        {
            Name = name;
        }
    }
}
