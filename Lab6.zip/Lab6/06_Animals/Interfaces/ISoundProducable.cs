﻿namespace _06_Animals.Interfaces
{
    interface ISoundProducable
    {
        string ProduceSound();
    }
}
