﻿namespace _01_RawData
{
    class Engine
    {
        public int Speed { get; }
        public int Power { get; }

        public Engine(int speed, int power)
        {
            Speed = speed;
            Power = power;
        }
    }
}
