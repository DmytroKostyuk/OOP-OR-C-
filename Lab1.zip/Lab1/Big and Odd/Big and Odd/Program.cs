﻿using System;

namespace Big_and_Odd
{
    class Program
    {
        static void Main(string[] args)
        {
            string str;
            int n;
            bool result;
            Console.WriteLine(" Enter your number :");
            str = Console.ReadLine();
            n = Convert.ToInt32(str);
            if (n > 20 && n % 2 != 0)
            {
                result = true;
                Console.WriteLine(result);
               
            }
            else
            {
                result = false;
                Console.WriteLine(result);
            }
        }
    }
}
