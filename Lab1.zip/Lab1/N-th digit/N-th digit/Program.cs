﻿using System;

namespace N_th_digit
{
    class Program
    {
        static void Main(string[] args)
        {
            string str;
            int number, n, nDigit;
            Console.WriteLine("enter number :");
            str = Console.ReadLine();
            number = Convert.ToInt32(str);
            Console.WriteLine("enter n :");
            str = Console.ReadLine();
            n = Convert.ToInt32(str);
            nDigit = ((int)(number / (Math.Pow (10, n - 1)) % 10));
            Console.WriteLine("Result : " + nDigit);
        }
    }
}
