﻿using System;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            string str;
            double a, b, h, area;
            Console.WriteLine("enter a :");
            str = Console.ReadLine();
            a = Convert.ToDouble(str);
            Console.WriteLine("enter b : ");
            str = Console.ReadLine();
            b = Convert.ToDouble(str);
            Console.WriteLine("enter h :");
            str = Console.ReadLine();
            h = Convert.ToDouble(str);
            area =((a+b)/2)*h ;
            Console.WriteLine(area);
        }
    }
}
