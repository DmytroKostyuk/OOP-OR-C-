﻿using System;

namespace last_digit
{
    class Program
    {
        static void Main(string[] args)
        {
            string str;
            double n, Lastdigit;
            Console.WriteLine(" enter n :");
            str = Console.ReadLine();
            n = Convert.ToInt32(str);
            Lastdigit = n%(10);
            Console.WriteLine(" your number : " +  Lastdigit);
        }
    }
}
