﻿using System;

namespace rotate_and_sum
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 0;
            Console.Write("Input size of array: ");
            n = int.Parse(Console.ReadLine());
            int[] array = new int[n];
            int[] sum = new int[n];
            Console.WriteLine("Input elemens: ");
            for (int i = 0; i < n; i++)
            {
                array[i] = int.Parse(Console.ReadLine());
                sum[i] = 0;
            }
            Console.Write("Array: ");
            foreach (int i in array)
            {
                Console.Write($"{i} ");
            }
            Console.WriteLine("");
            int rotate = 1;

            Console.Write("Input amount of rotations: ");
            rotate = int.Parse(Console.ReadLine());
            for (int i = 1; i <= rotate; i++)
            {
                int tmp = array[n - 1];
                for (int j = n - 1; j > 0; j--)
                {
                    array[j] = array[j - 1];
                }
                array[0] = tmp;
                for (int j = 0; j < n; j++)
                {
                    sum[j] += array[j];
                }
            }
            Console.Write("Sum of array: ");
            foreach (int i in sum)
            {
                Console.Write($"{i} ");
            }
        }

    }
}

