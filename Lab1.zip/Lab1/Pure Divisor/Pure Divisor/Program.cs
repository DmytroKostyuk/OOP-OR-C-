﻿using System;

namespace Pure_Divisor
{
    class Program
    {
        static void Main(string[] args)
        {
            string str;
            int n;
            //bool result;

            Console.WriteLine("Enter n :");
            str = Console.ReadLine();
            n = Convert.ToInt32(str);
            if (n % 9 == 0 || n % 11 == 0 || n % 13 == 0)
            {
                //result = true;
                Console.WriteLine(true);
            }
            else
                //result = false;
                Console.WriteLine(false);
        }
    }
}
