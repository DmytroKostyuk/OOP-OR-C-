﻿using System;

namespace Bigest_of_three
{
    class Program
    {
        static void Main(string[] args)
        {
            string str;
            int a, b, c;
            Console.WriteLine("Enter a :");
            str = Console.ReadLine();
            a = Convert.ToInt32(str);
            Console.WriteLine("Enter b :");
            str = Console.ReadLine();
            b = Convert.ToInt32(str); 
            Console.WriteLine("Enter c :");
            str = Console.ReadLine();
            c = Convert.ToInt32(str);
            if (a > b && a > c)
            {
                Console.WriteLine("Max:" + a);
            }
            if (a < b && b > c)
            {
                Console.WriteLine("Max:" + b);
            }
            if (c > a && c > b)
            {
                Console.WriteLine("Max:" + c);
            }
        }
    }
}
