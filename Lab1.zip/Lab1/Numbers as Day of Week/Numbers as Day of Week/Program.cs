﻿using System;

namespace Numbers_as_Day_of_Week
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Choose the number beetwen 1 to 7 :");
            double a =double.Parse(Console.ReadLine());
            switch (a)
            {
                case 1:
                    Console.WriteLine("Monday");
                    break;
                case 2:
                    Console.WriteLine("Tuesday");
                    break;
                case 3:
                    Console.WriteLine("Wensday");
                    break;
                case 4:
                    Console.WriteLine("Thursday");
                    break;
                case 5:
                    Console.WriteLine("Friday");
                    break;
                case 6:
                    Console.WriteLine("Saturday");
                    break;
                case 7:
                    Console.WriteLine("Sunday");
                    break;
                default:
                    Console.WriteLine("Your number is not valid");
                    break;
            }
        }
    }
}
