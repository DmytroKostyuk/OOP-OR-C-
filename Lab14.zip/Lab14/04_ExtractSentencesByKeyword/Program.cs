﻿using System;
using System.Text.RegularExpressions;

namespace _4_Extract_Sentences_by_Keyword
{
    class Program
    {
        static void Main(string[] args)
        {
            string word = Console.ReadLine();
            string pattern = $"(?<=\\s)[^\\.!?]+\\s{word}\\s[^\\.?!]+[\\.?!]|^[^\\.?!]+\\s{word}\\s[^\\.?!]+[\\.?!]";
            string text = "";
            while (true)
            {
                string str = Console.ReadLine();
                if (str == "") break;
                text += str + "\n";
            }
            MatchCollection matches = Regex.Matches(text, pattern);
            foreach (var item in matches)
            {
                Console.WriteLine(item);
            }
        }
    }
}