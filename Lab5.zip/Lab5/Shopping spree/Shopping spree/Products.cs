﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shopping_spree
{
    class Products
    {
        private string name;
        private double cost;
        public string Name
        {
            get => name;
            set
            {
                if (value == null || value == "")
                    throw new Exception("Name cant be empty!!");
                name = value;
            }
        }
        public double Cost
        {
            get => cost;
            set
            {
                if (value < 0)
                    throw new Exception("Cost cant be less than 0 ;");
                cost = value;
            }
        }
        public static Products Parse(string input)
        {
            string[] info = input.Split('=');
            return new Products(info[0], (int)double.Parse(info[1]));
        }
        public Products(string name,int cost)
        {
            Name = name;
            Cost = cost;
        }
    }
}
