﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shopping_spree
{
    class Person
    {
        private string name;
        private double money;
        private List<Products> bagOfProducts = new List<Products>();


        public string Name
        {
            get => name;
            set {
                if (value == null || value == "")
                    throw new Exception("You should enter the buyer's name");

                name = value;
            }
        }
        public double Money
        {
            get => money;
            set
            {
                if (value < 0)
                    throw new Exception("You cant have negative money");
                money = value;
            }
        }
        public string boughtProducts { get => GetBoughtProducts(); }
        public bool BoughtProducts { get; internal set; }

        public string Buy (Products products)
        {
            if (Money < products.Cost)
                return $"{Name} bought {products.Name}";
            Money -= products.Cost;
            return $"{Name} bought {products.Name}";
        }
        private string GetBoughtProducts()
        {
            string boughtProducts = $"{Name} - ";
            if (bagOfProducts.Count == 0)
                return boughtProducts + "Nothing bought";

            bool first = true;
            foreach (var item in bagOfProducts)
            {
                if (!first)
                    boughtProducts += ", ";

                boughtProducts += item.Name;
                first = false;
            }

            return boughtProducts;
        }
        public static Person Parse(string input)
        {
            string[] info = input.Split('=');
            return new Person(info[0], double.Parse(info[1]));
        }
        public Person(string name, double money)
        {
            Name = name;
            Money = money;
        }
    }
}